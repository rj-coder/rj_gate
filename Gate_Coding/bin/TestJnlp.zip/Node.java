package com.rj;

public class Node {

	
	private Node Link;
	public Node getLink() {
		return Link;
	}


	public void setLink(Node link) {
		Link = link;
	}


	public int getData() {
		return data;
	}


	public void setData(int data) {
		this.data = data;
	}


	private int data;

	
	
	


}

