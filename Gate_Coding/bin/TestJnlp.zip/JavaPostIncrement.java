package com.rj;

public class JavaPostIncrement {

	public JavaPostIncrement() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String args[]){
		int j=2;
		j=j+++j;//
		System.out.println(j);
		
	}

}
