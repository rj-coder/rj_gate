package com.rj;

public class NumberFormatException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4722477658671432541L;

	public NumberFormatException(String message) {
		super(message);
		
	}

	

}
